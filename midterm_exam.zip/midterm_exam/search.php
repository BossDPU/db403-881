<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Search product by category</title>
</head>
<body>
  <header>
<select name="pets" id="pet-select">
    <option value="">----</option>
    <option value="dog">Beverages</option>
    <option value="cat">Condiments</option>
    <option value="hamster">Confections</option>
    <option value="parrot">Darty Products</option>
    <option value="spider">Grains/Cereals</option>
    <option value="goldfish">Meat/Poultry</option>
    <option value="goldfish">produce</option>
    <option value="goldfish">Meat/Poultry</option>
</select>
        </select>
      </label>
      <input type="submit" value="Search" name="submit">
    </form>
  </header>
</body>
</html>